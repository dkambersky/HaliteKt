/**
 * Created by David on 14/01/2017.
 */

class MyBot{

}
